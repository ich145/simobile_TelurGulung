import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  constructor() { }

  logout() {
    alert('Logout berhasil!');
  }

  /*toggleDarkMode(event: any) {
    document.body.classList.toggle('dark', event.detail.checked);
  }*/
}
